<?php
require_once "conexao.php";

function cadastrar($nome, $email, $telefone) {
    global $conn;
    $sql = "INSERT INTO pessoa (nome_pessoa, email_pessoa, telefone_pessoa)
            VALUES (:nome, :email, :telefone)";
    $stmt = $conn->prepare($sql);
    return $stmt->execute([
        ':nome' => $nome,
        ':email' => $email,
        ':telefone' => $telefone
    ]);
}

function apagar($id) {
    global $conn;
    $sql = "DELETE FROM pessoa WHERE id_pessoa = :id";
    $stmt = $conn->prepare($sql);
    return $stmt->execute([':id' => $id]);
}

function atualizar($id, $nome, $email, $telefone) {
    global $conn;
    $sql = "UPDATE pessoa SET 
            nome_pessoa = :nome,
            email_pessoa = :email,
            telefone_pessoa = :telefone
            WHERE id_pessoa = :id";
    $stmt = $conn->prepare($sql);
    return $stmt->execute([
        ':id' => $id,
        ':nome' => $nome,
        ':email' => $email,
        ':telefone' => $telefone
    ]);
}

function consultar($id) {
    global $conn;
    $sql = "SELECT * FROM pessoa WHERE id_pessoa = :id";
    $stmt = $conn->prepare($sql);
    $stmt->execute([':id' => $id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}