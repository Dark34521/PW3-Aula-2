<?php
require_once "data.php";

$botao = $_POST['botao'];

switch ($botao) {

    case "CADASTRAR":
        cadastrar(
            $_POST['nome'],
            $_POST['email'],
            $_POST['telefone']
        );
        echo "Cadastrado com sucesso!";
        break;

    case "APAGAR":
        apagar($_POST['id']);
        echo "Registro apagado!";
        break;

    case "ATUALIZAR":
        atualizar(
            $_POST['id'],
            $_POST['nome'],
            $_POST['email'],
            $_POST['telefone']
        );
        echo "Atualizado com sucesso!";
        break;

    case "CONSULTAR":
        $resultado = consultar($_POST['id']);

        if ($resultado) {
            echo "ID: " . $resultado['id_pessoa'] . "<br>";
            echo "Nome: " . $resultado['nome_pessoa'] . "<br>";
            echo "Email: " . $resultado['email_pessoa'] . "<br>";
            echo "Telefone: " . $resultado['telefone_pessoa'];
        } else {
            echo "Registro não encontrado!";
        }
        break;
}