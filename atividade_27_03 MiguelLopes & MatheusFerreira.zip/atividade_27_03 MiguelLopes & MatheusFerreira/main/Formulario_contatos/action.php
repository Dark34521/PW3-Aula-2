<?php
require_once "data.php";

$pessoa = null;

if (isset($_GET['id'])) {
    $pessoa = buscar($_GET['id']);
}