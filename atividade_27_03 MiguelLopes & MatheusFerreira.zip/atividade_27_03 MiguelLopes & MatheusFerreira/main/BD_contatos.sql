create database bd_agenda_contatos;
use bd_agenda_contatos;

create table pessoa (
id_pessoa int primary key auto_increment,
nome_pessoa varchar(60) not null,
email_pessoa varchar(70) not null,
telefone_pessoa varchar(20),
data_criacao datetime default now()
);

insert into pessoa (nome_pessoa,email_pessoa,telefone_pessoa)values
('Gazola leite','gazolacheirador52@gmail.com','455 2558464'),
('Miguel Invincible Gas','miguel.silva294@gmail.com','67 65447505'),
('matheus bozo picante','matheus.bozo@17gmail.com','11 986551655');

select*from pessoa;

drop database conecta;